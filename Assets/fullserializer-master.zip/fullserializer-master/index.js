module.exports = function() { throw new Error('Not a javascript module'); };
