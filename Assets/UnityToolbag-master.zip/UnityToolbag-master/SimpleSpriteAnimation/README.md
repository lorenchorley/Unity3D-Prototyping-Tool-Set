A simpler frame based animation system for the new sprite feature of Unity 4.3. The animation is an asset you create and configure with frames, a frame duration, and a loop option. Then you put an animator on some object, assign its SpriteRenderer, and give it one or more animations. You can optionally have an animation play by default.

This isn't supposed to be super powerful to compete with the options of the Unity animation system, but it does provide a handy way to configure basic frame based sprite animations.
