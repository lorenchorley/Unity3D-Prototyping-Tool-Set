using UnityEngine;

namespace UnityToolbag
{
    // Component does nothing; editor script does all the magic
    [AddComponentMenu("UnityToolbag/Sorting Layer Exposed")]
    public class SortingLayerExposed : MonoBehaviour
    {
    }
}
