
public class SpawnPointTrace : BaseBehaviour
{
	// allows ProjectileManager.cs to easily cache a specific spawn point for its projectiles
}
