﻿public enum Side : byte { Right, Left, Top, Bottom };
public enum Position : byte { TopLeft, TopCenter, TopRight, MiddleLeft, MiddleCenter, MiddleRight, BottomLeft, BottomCenter, BottomRight }