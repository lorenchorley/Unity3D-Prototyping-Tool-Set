
public interface ICreatureController
{
	void MoveRight();
	void MoveLeft();
	void Jump();
	void Attack();
}
