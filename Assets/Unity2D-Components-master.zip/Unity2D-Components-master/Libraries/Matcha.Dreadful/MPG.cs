﻿
namespace Matcha.Dreadful
{
	static class MPG
	{
		// return various room coordinates for procedural generation
		public static int TopLeftX(ProcRoom room)
		{
			return room.originX;
		}
	}
}
