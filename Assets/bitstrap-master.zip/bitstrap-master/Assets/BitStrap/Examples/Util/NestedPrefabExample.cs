﻿using UnityEngine;

namespace BitStrap.Examples
{
	public class NestedPrefabExample : MonoBehaviour
	{
		[Header( "Enter play mode and see the Prefabs", order = 1 )]
		[Header( "being instantiated as a child.", order = 2 )]
		public bool dummy;
	}
}
