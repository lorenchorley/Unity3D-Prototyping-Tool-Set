﻿using UnityEngine;

namespace BitStrap.Examples
{
	public class DummyBehaviour : MonoBehaviour
	{
	}
}
