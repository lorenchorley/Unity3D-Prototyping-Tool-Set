using UnityEngine;

namespace BitStrap.Examples
{
	public sealed class GameObjectReferencesObject : ReferencesObject<GameObject>
	{
	}
}