using UnityEngine;

namespace BitStrap
{
	[System.AttributeUsage( System.AttributeTargets.Field )]
	public sealed class NullableAttribute : System.Attribute
	{
	}
}
