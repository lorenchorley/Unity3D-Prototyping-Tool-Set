namespace BitStrap
{
	public struct Unit
	{
	}
}